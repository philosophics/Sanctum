import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/philosophics/Sanctum/blob/main/texts/build.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/philosophics/Sanctum/blob/main/texts/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
