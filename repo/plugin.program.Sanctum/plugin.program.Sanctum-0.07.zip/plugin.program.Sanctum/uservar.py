import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://sanctum.foo/lib/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://sanctum.foo/lib/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']