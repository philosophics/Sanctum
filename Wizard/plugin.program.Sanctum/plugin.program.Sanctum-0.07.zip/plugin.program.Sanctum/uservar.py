import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://sanctum.foo/Wizard/resources/builds/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://sanctum.foo/Wizard/resources/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
