import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://philosophics.github.io/Sanctum/plugin.program.SanctumWiz/resources/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://philosophics.github.io/Sanctum/plugin.program.SanctumWiz/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
